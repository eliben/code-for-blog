import os
import pprint
import sys

print "\n'** Hello from pythonstartup.py'"
print "'** Imported: os, pprint, sys'"
print "'** sys.path is:'\n"
pprint.pprint(sys.path)
print ""


