import ctypes
from ctypes import windll
import socket
import struct


def GetIpAddrTable():
    """ Returns the interface-to-IP address mapping table.

        It can be used, for example, to find out the IP addresses
        assigned to all network interfaces on this computer.
        
        The value returned is a list of dictionaries, each with
        the following entries:
            ip_raw:     IP address, in raw format (long integer)
            ip_str:     IP address, represented as a dot-separated
                        quartet string (e.g. "123.0.100.78")
            mask:       Subnet mask
            bcast_addr: Broadcast address
            reasm_size: Maximum reassembly size
            type:       Address type or state
        
        Raises WindowsError if there's some a accessing the 
        system DLL.
        
        Note: The is basically a wrapper around GetIpAddrTable()
        from the Platform SDK. Read the documentation of that 
        function for more information.
    """
    DWORD = ctypes.c_ulong
    USHORT = ctypes.c_ushort
    NULL = ""
    
    dwSize = DWORD(0)
    
    # First call to receive the correct dwSize back.
    #
    windll.iphlpapi.GetIpAddrTable(NULL, ctypes.byref(dwSize), 0)

    class MIB_IPADDRROW(ctypes.Structure):
        _fields_ = [('dwAddr', DWORD),
                    ('dwIndex', DWORD),
                    ('dwMask', DWORD),
                    ('dwBCastAddr', DWORD),
                    ('dwReasmSize', DWORD),
                    ('unused1', USHORT),
                    ('wType', USHORT)]
    
    class MIB_IPADDRTABLE(ctypes.Structure):
        _fields_ = [('dwNumEntries', DWORD),
                    ('table', MIB_IPADDRROW * dwSize.value)]
    
    ipTable = MIB_IPADDRTABLE()
    if windll.iphlpapi.GetIpAddrTable(  ctypes.byref(ipTable), 
                                        ctypes.byref(dwSize), 
                                        0) != 0:
        raise WindowsError, "GetIpAddrTable returned %d" % rc
    
    table = []
    
    for i in range(ipTable.dwNumEntries):
        entry = dict(   ip_raw      = ipTable.table[i].dwAddr,
                        ip_str      = socket.inet_ntoa(struct.pack('L', ipTable.table[i].dwAddr)),
                        mask        = ipTable.table[i].dwMask,
                        bcast_addr  = ipTable.table[i].dwBCastAddr,
                        reasm_size  = ipTable.table[i].dwReasmSize,
                        type        = ipTable.table[i].wType,
                    )
                
        table.append(entry)
    
    return table

if __name__ == '__main__':
    table = GetIpAddrTable()
    
    import pprint
    pprint.pprint(table)

    



