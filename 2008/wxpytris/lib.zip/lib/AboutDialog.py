import wx
import wx.grid
import wx.html

import images


about_text = """\
wxPyTris is a simple, free Tetris clone, developed by
Eli Bendersky (http://eli.thegreenplace.net) in Python
using wxPython as the GUI toolkit.

It was tested on Windows and Linux with Python 2.5
and wxPython 2.8

Copyright (C) <2008> Eli Bendersky
License: LGPL (http://www.gnu.org/copyleft/lgpl.html)
"""


scoring_text = """\
The score in wxPyTris is computed as follows:

1) A point is earned for every line the active figure
is dropped with the 'space' key. For example, if you
pressed 'space' and the figure dropped 10 lines before
reaching the bottom, you get 10 points.

2) Points are awarded for completed lines, as follows:
30 points for a single line, 120 for two lines, 270
for three lines and 480 for four lines.

3) The bonuses explained in (1) and (2) are further
increased with higher levels. On level 2, the bonus
is multiplied by 1.1, on level 3 by 1.2, on level 4
by 1.3 and so on.

The game level increases with each 10 completed lines."""


keys_desc = [
    ('', ''),
    ('Left arrow', 'Move figure left'),
    ('Right arrow', 'Move figure right'),
    ('Down arrow', 'Move figure down faster'),
    ('Up arrow', 'Rotate figure clockwise'),
    ('Space', 'Drop figure'),
    ('Ctrl-H', 'Show high scores'),
    ('Ctrl-N', 'New game'),
    ('Ctrl-P', 'Pause / Resume game'),
    ('Ctrl-Q', 'Quit'),
    ('F1', 'About wxPyTris'),
    ]


class AboutDialog(wx.Dialog):
    def __init__(self, parent = None):
        wx.Dialog.__init__(self, parent, -1, 'About wxPyTris')

        nb = wx.Notebook(self, -1)

        #
        # About
        # 
        aboutPage = wx.Panel(nb, -1)
        sizer = wx.BoxSizer(wx.VERTICAL)
        bitmap = images.getLogoBitmap()
        image = wx.StaticBitmap(aboutPage, -1, bitmap, (0, 0), (bitmap.GetWidth(), bitmap.GetHeight()))
        sizer.Add(image, 0, wx.ALIGN_CENTER | wx.ALL, 10)
        sizer.Add(wx.StaticText(aboutPage, -1, about_text), 0, wx.ALIGN_LEFT | wx.ALL, 10)
        aboutPage.SetSizer(sizer)
        nb.AddPage(aboutPage, "About")
        
        #
        # Keys
        #
        keysPage = wx.Panel(nb, -1)
        
        grid = wx.FlexGridSizer(len(keys_desc), 3, 5, 5)
        
        for key, desc in keys_desc:
            blank_label = wx.StaticText(keysPage, -1, "    ")
            key_label = wx.StaticText(keysPage, -1, "%-14s" % key)
            desc_label = wx.StaticText(keysPage, -1, "%-40s" % desc)
            
            grid.Add(blank_label)
            grid.Add(key_label)
            grid.Add(desc_label)
            
        keysPage.SetSizer(grid)
        nb.AddPage(keysPage, "Keys")
        
        #
        # Scoring 
        #
        scoringPage = wx.Panel(nb, -1)
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(wx.StaticText(scoringPage, -1, scoring_text), 0, wx.ALIGN_LEFT | wx.ALL, 10)

        nb.AddPage(scoringPage, "Scoring")
        
        #
        # Dialog layout
        # 
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(nb, 0, wx.ALIGN_CENTRE|wx.ALL, 5)
        btn = wx.Button(self, wx.ID_OK)
        sizer.Add(btn, 0, wx.ALIGN_CENTRE|wx.ALL, 5)

        self.SetSizer(sizer)
        self.Layout()
        self.Fit()
        


if __name__ == "__main__":
    app = wx.PySimpleApp()

    dlg = AboutDialog()
    dlg.ShowModal()
    dlg.Destroy()

    app.MainLoop()

