import os
import pprint
import sys
import wx
import wx.html

from eblib.enum import Enum
from eblib.struct import Struct
from highscores import HighScores
from AboutDialog import AboutDialog
from HighscoresDialog import HighscoresDialog
import images
from tetris_model import TetrisBoard, Figure, FigureBank
from version import wxpytris_version


class DrawableTetrisBoard(wx.Window):
    """ A base class for tetris board windows that can draw themselves.
    """
    def __init__(self, parent, ID, nrows, ncols, blocksize):
        wx.Window.__init__(self, parent, ID)
        
        self.nrows = nrows
        self.ncols = ncols
        self.blocksize = blocksize
        self.showgrid = True
        self.gridwidth = 2
        self.gridcolor = wx.Colour(204, 204, 204)
        self.sinkwidth = 4
        self.sinkcolor = 'white'
        self.blockBorderColor = 'black'
        self.bgcolor = wx.Colour(234, 234, 244)
        
        self.width = self.sinkwidth * 2 + ncols * blocksize + (ncols + 1) * self.gridwidth
        self.height = self.sinkwidth * 2 + nrows * blocksize + (nrows + 1) * self.gridwidth
        self.SetClientSize((self.width, self.height))
        self.SetMinSize((self.width, self.height))

        self.board = TetrisBoard(nrows, ncols)

        self.Bind(wx.EVT_PAINT, self.OnPaint)
    
    def SetShowGrid(self, showgrid):
        self.showgrid = showgrid
    
    def InitBuffer(self):
        w, h = self.GetClientSize()
        self.buffer = wx.EmptyBitmap(w, h)
        dc = wx.BufferedDC(wx.ClientDC(self), self.buffer)
        self.DrawBoard(dc)
    
    def OnPaint(self, evt):
        dc = wx.BufferedPaintDC(self, self.buffer)
    
    def DrawBoard(self, dc = None):
        if not dc:
            dc = wx.BufferedDC(wx.ClientDC(self), self.buffer)
        
        dc.SetBackground(wx.Brush(self.bgcolor))
        dc.Clear()
        
        self.DrawSink(dc)
        if self.showgrid: self.DrawGrid(dc)
            
        self.DrawAllBlocks(dc)

    def DrawSink(self, dc):
        dc.SetPen(wx.Pen(self.sinkcolor, self.sinkwidth))        
        dc.SetBrush(wx.Brush('white', wx.TRANSPARENT))
        
        halfsink = self.sinkwidth / 2
        
        dc.DrawLine(halfsink, 0, halfsink, self.height) 
        dc.DrawLine(self.width - halfsink, 0, 
                    self.width - halfsink, self.height)
        dc.DrawLine(0, halfsink, self.width, halfsink)
        dc.DrawLine(0, self.height - halfsink, 
                    self.width, self.height - halfsink)
        
    def DrawGrid(self, dc):
        dc.SetPen(wx.Pen(self.gridcolor, self.gridwidth))
        
        # horizontal
        for row in range(self.nrows + 1):
            dc.DrawLine(self.sinkwidth,
                        self.sinkwidth + row * (self.blocksize + self.gridwidth) + 1,
                        self.width - 1 - self.sinkwidth,
                        self.sinkwidth + row * (self.blocksize + self.gridwidth) + 1)
        
        # vertical
        for col in range(self.ncols + 1):
            dc.DrawLine(self.sinkwidth + col * (self.blocksize + self.gridwidth) + 1, 
                        self.sinkwidth, 
                        self.sinkwidth + col * (self.blocksize + self.gridwidth) + 1, 
                        self.height - 1 - self.sinkwidth)

    def DrawAllBlocks(self, dc):
        board = self.board.BoardWithActiveFigure()
        
        for row in range(self.nrows):
            for col in range(self.ncols):
                color = board[row][col]
                
                if color != 0:
                    self.DrawBlock(dc, row, col, color)
                    
    def DrawBlock(self, dc, row, col, color):
        dc.SetPen(wx.Pen(self.blockBorderColor, self.gridwidth))
        dc.SetBrush(wx.Brush(color))
        
        dc.DrawRectangle(   self.sinkwidth + col * (self.blocksize + self.gridwidth) + 1,
                            self.sinkwidth + row * (self.blocksize + self.gridwidth) + 1,
                            self.blocksize + self.gridwidth + 1,
                            self.blocksize + self.gridwidth + 1)


class TetrisBoardWindow(DrawableTetrisBoard):
    """ The main tetris window type, with an active figure that can be moved
        around, dropped, etc. and a bunch of inactive blocks.
        Supports all the expected tetris operations, like removing completed
        rows and generating new figures.
    """
    def __init__(self, parent, ID, nrows, ncols, blocksize, startfigure):
        DrawableTetrisBoard.__init__(self, parent, ID, nrows, ncols, blocksize)
        
        self.board.SpawnFigure(startfigure)
        self.InitBuffer()
        
        # Keeps track of the amount of rows the active figure
        # fell in the last "drop" command. This is used to 
        # update the score.
        #
        self.lastDropHeight = 0

    def Restart(self, startfigure):
        self.board = TetrisBoard(self.nrows, self.ncols)
        self.board.SpawnFigure(startfigure)
        self.DrawBoard()
    
    def KeyPress(self, evt):
        self.lastDropHeight = 0
        
        key = evt.GetKeyCode()
        
        if key == wx.WXK_LEFT:
            self.board.MoveFigureLeft()
        elif key == wx.WXK_RIGHT:
            self.board.MoveFigureRight()
        elif key == wx.WXK_DOWN:
            self.board.MoveFigureDown()
        elif key == wx.WXK_UP:
            self.board.RotateFigure()
        elif key == wx.WXK_SPACE:
            for i in range(self.nrows):
                if not self.board.MoveFigureDown():
                    self.lastDropHeight = i
                    break
        else:
            return

        self.DrawBoard()

    def Tick(self, nextfigure):
        """ One timer tick for the tetris game.
            
            Advances the game by one step and returns a result structure with 
            the following attributes:
            
                result.state:   
                    The game state.
                        running -   The current figure was moved down by one
                                    cell successfully.
                        newfigure - The current figure could no longer be 
                                    moved down, so a new figure was created.
                        gameover -  The current figure could no longer be
                                    moved down, and a new figure could not be
                                    created.
                result.completed_rows:
                    A list of row numbers that were completed with the 
                    current figure reaching bottom. It is applicable in the
                    "newfigure" state
                
                result.drop_height: 
                    The amount of lines the figure was dropped in the last 
                    drop.
        """
        result = Struct(state = "running", 
                        completed_rows = [], 
                        nlines = 0)
                                
        if self.board.MoveFigureDown():
            result.state = "running"
        else:
            result.completed_rows = self.board.FinishFall()
            
            if self.board.SpawnFigure(nextfigure):
                result.state = "newfigure"
            else:
                result.state = "gameover"
        
        result.drop_height = self.lastDropHeight
        self.lastDropHeight = 0
        
        self.DrawBoard()
        return result


class TetrisPreviewWindow(DrawableTetrisBoard):
    """ A preview window for figures. Only shows a single figure, trying to
        center it vertically.
        Note: the success of this method depends on the actual figures that
        participate in the game. It works well for the default 7 Tetris
        figures.
    """
    def __init__(self, parent, ID, nrows, ncols, blocksize):
        DrawableTetrisBoard.__init__(self, parent, ID, nrows, ncols, blocksize)
        self.SetShowGrid(False)
        
        self.InitBuffer()
        self.figure = None
    
    def SetFigure(self, figure):
        self.figure = figure
        self.board = TetrisBoard(self.nrows, self.ncols)
        self.board.SpawnFigure(figure)
        self.board.MoveFigureDown()
        self.board.MoveFigureDown()
        
        self.DrawBoard()


class TetrisGame(wx.Frame):
    """ The main game frame.
    """
    def __init__(self, parent):
        wx.Frame.__init__(self, parent, -1, "wxPyTris v%s" % wxpytris_version,
                            style = wx.MINIMIZE_BOX | wx.SYSTEM_MENU |
                                    wx.CAPTION | wx.CLOSE_BOX | wx.CLIP_CHILDREN)
        self.SetIcon(images.getIcon())        
        
        self.figurebank = self.MakeFigureBank()
        self.previewfigure = self.figurebank.GetRandom()

        self.boardWindow = TetrisBoardWindow(   self, 
                                                -1, 
                                                nrows = 20, 
                                                ncols = 10, 
                                                blocksize = 25,
                                                startfigure = self.figurebank.GetRandom())

        self.GameState = Enum('running', 'paused', 'gameover')
        
        self.gameLevel = 1
        self.gameLinesCount = 0
        self.gameScore = 0
        self.state = self.GameState.running
       
        self.controlPanel = wx.Panel(self, -1, style = wx.SUNKEN_BORDER)
        
        box = wx.BoxSizer(wx.HORIZONTAL)
        box.Add(self.boardWindow)
        box.Add(self.controlPanel, flag = wx.EXPAND)
        self.SetSizer(box)
        
        self.InitHighScores()
        self.PopulateControlPanel()
        self.MakeStatusBar()
        self.MakeMenuBar()
        
        box.Fit(self)
        box.SetSizeHints(self)
        
        self.boardWindow.Bind(wx.EVT_CHAR, self.OnChar)
        self.Bind(wx.EVT_TIMER, self.OnTimer)
        self.Bind(wx.EVT_IDLE, self.OnIdle)

        self.timerInterval = 1000
        self.timer = wx.Timer(self)
        self.timer.Start(self.timerInterval)
        
        self.boardWindow.SetFocus()
        
    def MenuData(self):
        return (("&Game",
                    ("&New\tCtrl-N", "New game", self.OnRestartButton),
                    ("&Pause\tCtrl-P", "Pause game", self.OnPauseButton),
                    ("", "", ""),
                    ("&High Scores\tCtrl-H", "Show high scores", self.OnHighScores),
                    ("", "", ""),
                    ("&Quit\tCtrl-Q", "Quit", self.OnCloseWindow)),
                ("&Help",
                    ("&About\tF1", "About wxPyTris", self.OnAbout)))

    def CreateMenu(self, menuData):
        menu = wx.Menu()
        for eachLabel, eachStatus, eachHandler in menuData:
            if not eachLabel:
                menu.AppendSeparator()
                continue
            menuItem = menu.Append(-1, eachLabel, eachStatus)
            self.Bind(wx.EVT_MENU, eachHandler, menuItem)
        return menu

    def MakeMenuBar(self):
        menuBar = wx.MenuBar()
        for eachMenuData in self.MenuData():
            menuLabel = eachMenuData[0]
            menuItems = eachMenuData[1:]
            menuBar.Append(self.CreateMenu(menuItems), menuLabel)
        self.SetMenuBar(menuBar)
    
    def MakeStatusBar(self):
        self.CreateStatusBar(1)
    
    def PopulateControlPanel(self):
        hbox = wx.BoxSizer(wx.HORIZONTAL)
        hbox.AddSpacer(40)
        
        vbox = wx.BoxSizer(wx.VERTICAL)
        hbox.Add(vbox)
        hbox.AddSpacer(40)
        
        vbox.AddSpacer(40)
        
        sbox = wx.StaticBox(self.controlPanel, -1, "Preview")
        ssizer = wx.StaticBoxSizer(sbox, wx.VERTICAL)
        
        self.previewPan = TetrisPreviewWindow(
                            self.controlPanel, 
                            -1, 
                            nrows = 7, 
                            ncols = 7, 
                            blocksize = 10)
        self.previewPan.SetFigure(self.previewfigure)
        ssizer.Add(self.previewPan)
        
        vbox.Add(ssizer, flag = wx.ALIGN_CENTER)
        vbox.AddSpacer(60)

        statsbox = wx.GridSizer(rows = 3, cols = 2, vgap = 10)
        vbox.Add(statsbox, flag = wx.EXPAND)   
        vbox.AddSpacer(40)
        
        buttonbox = wx.BoxSizer(wx.HORIZONTAL)
        vbox.Add(buttonbox, flag = wx.EXPAND)
        
        font = wx.Font(18, wx.SWISS, wx.NORMAL, wx.NORMAL)
        levelLabel = wx.StaticText( self.controlPanel,
                                    -1,
                                    "Level",
                                    style = wx.ALIGN_LEFT | wx.ST_NO_AUTORESIZE,
                                    size = (90, -1))
        self.levelText = wx.StaticText( self.controlPanel,
                                        -1, 
                                        str(self.gameLevel),
                                        style = wx.ALIGN_RIGHT | wx.ST_NO_AUTORESIZE,
                                        size = (90, -1))
        linesLabel = wx.StaticText( self.controlPanel,
                                    -1,
                                    "Lines",
                                    style = wx.ALIGN_LEFT | wx.ST_NO_AUTORESIZE,
                                    size = (90, -1))
        self.linesText = wx.StaticText( self.controlPanel,
                                        -1, 
                                        str(self.gameLinesCount),
                                        style = wx.ALIGN_RIGHT | wx.ST_NO_AUTORESIZE,
                                        size = (90, -1))
        scoreLabel = wx.StaticText( self.controlPanel,
                                    -1,
                                    "Score",
                                    style = wx.ALIGN_LEFT | wx.ST_NO_AUTORESIZE,
                                    size = (90, -1))
        self.scoreText = wx.StaticText( self.controlPanel,
                                        -1, 
                                        str(self.gameScore),
                                        style = wx.ALIGN_RIGHT | wx.ST_NO_AUTORESIZE,
                                        size = (90, -1))
        
        for lbl in [levelLabel, self.levelText, 
                    linesLabel, self.linesText,
                    scoreLabel, self.scoreText]:
            lbl.SetFont(font)
            statsbox.Add(lbl)
        
        self.pauseButton = wx.Button(   self.controlPanel, 
                                        -1, 
                                        "Pause game",
                                        size = (90, 40))
                                        
        self.Bind(wx.EVT_BUTTON, self.OnPauseButton, self.pauseButton)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdatePauseButton, self.pauseButton)

        self.restartButton = wx.Button( self.controlPanel,
                                        -1,
                                        "New game",
                                        size = (90, 40))
        
        buttonbox.Add(self.pauseButton)
        buttonbox.AddSpacer(20)
        buttonbox.Add(self.restartButton)
        
        self.Bind(wx.EVT_BUTTON, self.OnRestartButton, self.restartButton)
    
        self.controlPanel.SetSizer(hbox)
        self.controlPanel.Fit()
    
    def OnCloseWindow(self, evt):
        self.Destroy()
    
    def OnAbout(self, evt):
        state = self.state
        self.state = self.GameState.paused

        dialog = AboutDialog(self)
        dialog.ShowModal()
        dialog.Destroy()
        
        self.state = state
    
    def OnHighScores(self, evt):
        self.ShowHighScores()
    
    def OnChar(self, evt):
        if self.state == self.GameState.running:
            self.boardWindow.KeyPress(evt)
    
    def OnUpdatePauseButton(self, evt):
        if self.state == self.GameState.paused:
            self.pauseButton.SetLabel("Resume game")
        elif self.state == self.GameState.running or self.state == self.GameState.gameover:
            self.pauseButton.SetLabel("Pause game")
        
    def OnPauseButton(self, evt):
        if self.state == self.GameState.paused:
            self.ResumeGame()
        elif self.state == self.GameState.running:
            self.PauseGame()
    
    def OnRestartButton(self, evt):
        if self.state == self.GameState.gameover:
            self.RestartGame()
        else:
            state = self.state
            self.state = self.GameState.paused
            
            dlg = wx.MessageDialog( None, 
                                    "Are you sure you want to restart ?",
                                    "Restart configmation",
                                    wx.YES_NO | wx.ICON_QUESTION)
            rc = dlg.ShowModal()
            
            if rc == wx.ID_YES:
                self.RestartGame()
            else:
                self.state = state
            
            dlg.Destroy()
        
        self.boardWindow.SetFocus()
    
    def OnIdle(self, evt):
        if self.state == self.GameState.running:
            self.SetStatusText("Playing", 0)
        elif self.state == self.GameState.paused:
            self.SetStatusText("Paused", 0)
        elif self.state == self.GameState.gameover:
            self.SetStatusText("Game Over!", 0)  
    
    def OnTimer(self, evt):
        if self.state == self.GameState.running:
            result = self.boardWindow.Tick(self.previewfigure)
            num_rows = len(result.completed_rows)

            if result.state == "gameover":
                self.GameOver()
            elif result.state == "newfigure":
                old_line_count = self.gameLinesCount
                self.gameLinesCount += num_rows
                score_bonus = (result.drop_height + num_rows ** 2 * 30)
                score_bonus = int(score_bonus * (1 + 0.1 * (self.gameLevel - 1)))
                self.gameScore += score_bonus
                self.previewfigure = self.figurebank.GetRandom()
                self.previewPan.SetFigure(self.previewfigure)
                
                if (num_rows > 0 and old_line_count % 10 + num_rows >= 10):
                    self.gameLevel += 1
                    self.timerInterval = 1000 - (self.gameLevel * 100)
                    if self.timerInterval < 100: self.timerInterval = 100
                    self.timer.Stop()
                    self.timer.Start(self.timerInterval)
            
            self.UpdateStats()

        self.boardWindow.SetFocus()
        
    def UpdateStats(self):
        self.levelText.SetLabel(str(self.gameLevel))
        self.linesText.SetLabel(str(self.gameLinesCount))
        self.scoreText.SetLabel(str(self.gameScore))
    
    def SetGameState(self, state):
        self.state = state
            
    def PauseGame(self):
        self.SetGameState(self.GameState.paused)
        self.timer.Stop()
        self.boardWindow.SetFocus()
    
    def ResumeGame(self):
        self.SetGameState(self.GameState.running)
        self.timer.Start(self.timerInterval)
        self.boardWindow.SetFocus()
    
    def RestartGame(self):
        self.gameLevel = 1
        self.gameLinesCount = 0
        self.gameScore = 0
        self.timerInterval = 1000
        
        self.ResumeGame()
        self.UpdateStats()
        
        self.boardWindow.Restart(self.figurebank.GetRandom())
        self.previewfigure = self.figurebank.GetRandom()
        self.previewPan.SetFigure(self.previewfigure)
        self.timer.Start(self.timerInterval)

    def GameOver(self):
        self.SetGameState(self.GameState.gameover)
        self.timer.Stop()
        
        if self.gameScore > self.highscores.lowest_score():
            dialog = wx.TextEntryDialog(None, 
                            "Your name:",
                            "You've made it into the high scores!", style = wx.OK)
            
            if dialog.ShowModal() == wx.ID_OK:
                name = dialog.GetValue()
                self.highscores.add_score(name, self.gameScore)
                self.SaveHighScores()
                self.ShowHighScores()
            
            dialog.Destroy()

    def MakeFigureBank(self):
        # The standard 7 Tetris figures, in the orientation
        # in which they appear from the top of the screen
        #
        
        #  oo
        # oO
        S = Figure([(0,0), (-1,0), (0,-1), (-1,1)], color = wx.Colour(122, 197, 205))
        
        # oo
        #  Oo
        Z = Figure([(0,0), (0,1), (-1,-1), (-1,0)], color = wx.Colour(0, 205, 0))
        
        # oOo
        #  o
        T = Figure([(0,0), (0,1), (0,-1), (1,0)], color = wx.Colour(238, 238, 0))
        
        # oOoo
        #
        I = Figure([(0,0), (0,-1), (0,1), (0,2)], color = wx.Colour(238, 118, 33))
        
        # oo
        # Oo
        O = Figure([(0,0), (-1,0), (-1,1), (0,1)], rotatable = False, color = wx.Colour(238, 44, 44))
        
        # oOo
        # o
        L = Figure([(0,0), (0,-1), (0,1), (1,-1)], color = wx.Colour(0, 0, 225))
        
        # oOo
        #   o
        J = Figure([(0,0), (0,-1), (0,1), (1,1)], color = wx.Colour(148, 0, 211))
        
        return FigureBank([S, Z, T, I, O, L, J])

    HS_FILENAME = "wxpytris_highscores"

    def InitHighScores(self):
        """ Initializes the high-scores list of the game.
            
            All later methods that deal with high-scores assume
            Init has been called.
        """
        self.highscores = HighScores(10)
        
        if os.path.exists(self.HS_FILENAME):
            self.highscores.load_from_file(self.HS_FILENAME)
    
    def SaveHighScores(self):
        self.highscores.save_to_file(self.HS_FILENAME)
        
    def ScoreHighEnough(self, score):
        return 

    def ShowHighScores(self):
        state = self.state
        self.state = self.GameState.paused

        dialog = HighscoresDialog(self, self.highscores.get_list())
        dialog.ShowModal()
        dialog.Destroy()
        
        self.state = state
